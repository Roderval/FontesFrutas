import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import axios from 'axios';
import { Table, Button } from 'antd';
import { getFruits } from '../../../actions/fruits';
import './FruitsTable.css';

const { Column } = Table;

const FruitsTable = ({ getFruits, fruits }) => {
  useEffect(() => {
    getFruits();
  }, [getFruits]);

  const deleteFruit = fruitData => {
    const { id_fruta } = fruitData;

    axios
      .delete('/api/frutas', { data: { id_fruta } })
      .then(res => {
        getFruits();
      })
      .catch(err => {
        console.log(err);
      });
  };

  return (
    <Table className="fruit-table" dataSource={fruits}>
      <Column title="ID" dataIndex="id_fruta" key="id_fruta" />
      <Column title="Nome" dataIndex="nome_fruta" key="nome_fruta" />
      <Column title="Lote" dataIndex="lote_fruta" key="lote_fruta" />
      <Column title="Cultivo" dataIndex="cultivar_fruta" key="cultivar_fruta" />
      <Column title="Safra" dataIndex="safra_fruta" key="safra_fruta" />
      <Column
        title="Colheita"
        dataIndex="colheita_fruta"
        key="colheita_fruta"
      />
      <Column title="Status" dataIndex="status_fruta" key="status_fruta" />
      <Column
        key="action"
        render={(text, record) => (
          <Button type="danger" onClick={() => deleteFruit(record)}>
            Deletar
          </Button>
        )}
      />
    </Table>
  );
};

FruitsTable.propTypes = {
  getFruits: PropTypes.func.isRequired,
  fruits: PropTypes.array,
};

const mapStateToProps = state => ({
  fruits: state.fruits.data,
});

export default connect(
  mapStateToProps,
  { getFruits }
)(FruitsTable);
