import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import axios from 'axios';
import moment from 'moment';
import { Form, Input, Select, DatePicker, Button } from 'antd';
import { getFruits } from '../../../actions/fruits';
import './FruitRegistration.css';

const Option = Select.Option;

class FruitForm extends Component {
  handleSubmit = e => {
    e.preventDefault();

    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.sendFormData(values);
      }
    });
  };

  sendFormData = data => {
    let newFruit = {
      nome_fruta: data.nome_fruta,
      cultivar_fruta: data.cultivar_fruta,
      lote_fruta: data.lote_fruta,
      safra_fruta: data.safra_fruta.format('YYYY-MM-DD'),
      colheita_fruta: data.colheita_fruta.format('YYYY-MM-DD'),
      datacad_fruta: moment().format('YYYY-MM-DD'),
      status_fruta: data.status_fruta,
    };

    axios
      .post('/api/frutas', newFruit)
      .then(res => {
        this.props.getFruits();
      })
      .catch(err => {
        console.log(err);
      });
  };

  render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <Form className="fruit-form" layout="inline" onSubmit={this.handleSubmit}>
        <h1 className="section-title">Registrar Nova Fruta</h1>
        <Form.Item label="Nome da Fruta">
          {getFieldDecorator('nome_fruta', {
            rules: [{ required: true, message: 'Digite o nome da fruta' }],
          })(<Input placeholder="Nome" />)}
        </Form.Item>
        <Form.Item label="Cultivar fruta">
          {getFieldDecorator('cultivar_fruta', {
            rules: [{ required: true, message: 'Cultivar fruta' }],
          })(<Input placeholder="Cultivar" />)}
        </Form.Item>
        <Form.Item label="Lote da fruta">
          {getFieldDecorator('lote_fruta', {
            rules: [{ required: true, message: 'Digite o lote da fruta' }],
          })(<Input placeholder="Lote" />)}
        </Form.Item>
        <Form.Item label="Safra da fruta">
          {getFieldDecorator('safra_fruta', {
            rules: [{ required: true, message: 'Digite a safra da fruta' }],
          })(<DatePicker placeholder="Data" />)}
        </Form.Item>
        <Form.Item label="Colheita da fruta">
          {getFieldDecorator('colheita_fruta', {
            rules: [
              {
                type: 'object',
                required: true,
                message: 'Digite a colheita da fruta',
              },
            ],
          })(<DatePicker placeholder="Data" />)}
        </Form.Item>
        <Form.Item label="Status da fruta">
          {getFieldDecorator('status_fruta', {
            rules: [
              { required: true, message: 'Status da fruta é necessário' },
            ],
          })(
            <Select
              showSearch
              style={{ width: 200 }}
              name="statusFruta"
              label="status_fruta"
              placeholder="Status"
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="1">1</Option>
              <Option value="2">2</Option>
              <Option value="3">3</Option>
            </Select>
          )}
        </Form.Item>
        <Button
          style={{ marginTop: 10 }}
          htmlType="submit"
          type="primary"
          block
        >
          Enviar
        </Button>
      </Form>
    );
  }
}

FruitForm.propTypes = {
  getFruits: PropTypes.func.isRequired,
};

const FruitRegistration = Form.create({ name: 'fruit_form' })(FruitForm);

export default connect(
  null,
  { getFruits }
)(FruitRegistration);
