import React, { Component } from 'react';
import Diagram from './MonitoringPage/Diagram';

export default class MonitoringPage extends Component {
  render() {
    return (
      <div>
        <Diagram />
      </div>
    );
  }
}
