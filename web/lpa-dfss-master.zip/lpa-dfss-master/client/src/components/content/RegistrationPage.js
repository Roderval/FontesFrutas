import React, { Component } from 'react';
import FruitRegistration from './RegistrationPage/FruitRegistration';
import FruitsTable from './RegistrationPage/FruitsTable';

export default class RegistrationPage extends Component {
  render() {
    return (
      <>
        <FruitRegistration />
        <FruitsTable />
      </>
    );
  }
}
