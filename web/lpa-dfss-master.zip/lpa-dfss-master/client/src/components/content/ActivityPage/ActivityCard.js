import React from 'react';
import PropTypes from 'prop-types';
import WrappedActivityForm from './ActivityForm';
import ActivityStatus from './ActivityStatus';
import './ActivityCard.css';

function ActivityCard({ id, status, data, reload }) {
  return (
    <div className="activity-card">
      <h1 className="section-title">{`Câmara ${id}`}</h1>
      {status === 'ON' ? (
        <ActivityStatus data={data} reload={reload} />
      ) : (
        <WrappedActivityForm id={id} reload={reload} />
      )}
    </div>
  );
}

ActivityCard.propTypes = {
  id: PropTypes.number.isRequired,
  status: PropTypes.string.isRequired,
  data: PropTypes.object,
  reload: PropTypes.func.isRequired,
};

export default ActivityCard;
