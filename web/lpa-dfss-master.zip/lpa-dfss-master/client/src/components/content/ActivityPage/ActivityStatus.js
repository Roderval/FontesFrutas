import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'antd';
import axios from 'axios';
import './ActivityStatus.css';

export default class ActivityStatus extends Component {
  constructor(props) {
    super(props);

    this.handleClickStop = this.handleClickStop.bind(this);
  }

  handleClickStop() {
    axios
      .post('/api/atividades/update', {
        id_atividade: this.props.data.id_atividade,
        status_atividade: 4,
      })
      .then(res => {
        console.log(res);

        this.props.reload();
      })
      .catch(err => {
        console.log(err);
      });
  }

  render() {
    return (
      <div className="activity-status">
        <p>
          <b>Nome:</b> {this.props.data.nome_atividade}
        </p>
        <p>
          <b>ID atividade:</b> {this.props.data.id_atividade}
        </p>
        <p>
          <b>Status:</b> {this.props.data.status_atividade}
        </p>
        <p>
          <b>Data Inicial:</b> {this.props.data.datainicial_atividade}
        </p>
        <p>
          <b>Data Final:</b> {this.props.data.datafinal_atividade}
        </p>
        <p>
          <b>Modo de Operação:</b> {this.props.data.modoop_atividade}
        </p>
        <p>
          <b>Set Point CO2:</b> {this.props.data.setpointCO2_atividade}
        </p>
        <p>
          <b>Set Point O2:</b> {this.props.data.setpointO2_atividade}
        </p>

        <Button type="danger" onClick={this.handleClickStop} ghost block>
          Parar
        </Button>
      </div>
    );
  }
}

ActivityStatus.propTypes = {
  data: PropTypes.object.isRequired,
  reload: PropTypes.func.isRequired,
};
