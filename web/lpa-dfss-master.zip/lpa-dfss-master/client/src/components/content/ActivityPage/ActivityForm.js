import React, { Component } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import moment from 'moment';
import {
  Form,
  Input,
  Select,
  InputNumber,
  DatePicker,
  Button,
  TimePicker,
} from 'antd';
import { connect } from 'react-redux';
import './ActivityForm.css';
import { getFruits } from '../../../actions/fruits';
import FormItem from 'antd/lib/form/FormItem';

const Option = Select.Option;

const { RangePicker } = DatePicker;

class ActivityForm extends Component {
  handleSubmit = e => {
    e.preventDefault();

    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.sendFormData(values);
      }
    });
  };

  componentWillMount = () => {
    this.props.getFruits();
  };

  sendFormData = data => {
    let newActivity = {
      nome: data.nome,
      modoop: data.modoop,
      frutas: data.fruta,
      id_camara: this.props.id,
      setpointO2: data.setpointO2,
      setpointCO2: data.setpointCO2,
      datainicial:
        data.periodo_atividade[0].format('YYYY-MM-DD') +
        ' ' +
        data.hora_inicio.format('HH:mm:ss'),
      datafinal:
        data.periodo_atividade[1].format('YYYY-MM-DD') +
        ' ' +
        data.hora_fim.format('HH:mm:ss'),
      datacad: moment().format('YYYY-MM-DD'),
    };

    axios
      .post('/api/atividades/add', newActivity)
      .then(res => {
        console.log(res);

        this.props.reload();
      })
      .catch(err => {
        console.log(err);
      });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const fruits = this.props.fruits.map(fruit => {
      return <Option value={fruit.id_fruta}>{fruit.nome_fruta}</Option>;
    });

    return (
      <Form onSubmit={this.handleSubmit}>
        <Form.Item label="Nome da atividade">
          {getFieldDecorator('nome', {
            rules: [{ required: true, message: 'Digite o nome da atividade' }],
          })(<Input placeholder="Nome" />)}
        </Form.Item>
        <Form.Item label="Modo de Operação">
          {getFieldDecorator('modoop', {
            rules: [{ required: true, message: 'Modo de opeção é necessário' }],
          })(
            <Select
              showSearch
              style={{ width: 200 }}
              name="modoOperacao"
              label="modoop"
              placeholder="Selecione o M.O."
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
            >
              <Option value="1">Estático</Option>
              <Option value="2">Estático Smart</Option>
              <Option value="3">RQ Estático</Option>
              <Option value="4">RQ Smart</Option>
            </Select>
          )}
        </Form.Item>
        <Form.Item label="Frutas">
          {getFieldDecorator('fruta', {
            rules: [{ required: true, message: 'Fruta é necessária' }],
          })(
            <Select
              showSearch
              style={{ width: 200 }}
              placeholder="Selecione a Fruta."
              name="fruta"
              onChange={this.handleChange}
              filterOption={(input, option) =>
                option.props.children
                  .toLowerCase()
                  .indexOf(input.toLowerCase()) >= 0
              }
            >
              {fruits}
            </Select>
          )}
        </Form.Item>
        <Form.Item label="Set Point O2">
          {getFieldDecorator('setpointO2', {
            rules: [{ required: false }],
          })(<InputNumber min={0} max={20} step={0.1} />)}
        </Form.Item>
        <Form.Item label="Set Point CO2">
          {getFieldDecorator('setpointCO2', {
            rules: [{ required: false }],
          })(<InputNumber min={0} max={20} step={0.1} />)}
        </Form.Item>
        <Form.Item label="Período">
          {getFieldDecorator('periodo_atividade', {
            rules: [
              { required: true, message: 'Escolha o período da atividade' },
            ],
          })(<RangePicker />)}
        </Form.Item>
        <FormItem>
          {getFieldDecorator('hora_inicio', {
            rules: [
              { required: true, message: 'Escolha o período da atividade' },
            ],
          })(<TimePicker placeholder="Tempo início" />)}
        </FormItem>
        <FormItem>
          {getFieldDecorator('hora_fim', {
            rules: [
              { required: true, message: 'Escolha o período da atividade' },
            ],
          })(<TimePicker placeholder="Tempo fim" />)}
        </FormItem>
        <Button
          style={{ marginTop: 10 }}
          htmlType="submit"
          type="primary"
          block
        >
          Enviar
        </Button>
      </Form>
    );
  }
}

ActivityForm.propTypes = {
  id: PropTypes.number.isRequired,
  reload: PropTypes.func.isRequired,
  getFruits: PropTypes.func.isRequired,
  fruits: PropTypes.array,
};

const WrappedActivityForm = Form.create({ name: 'activity_register' })(
  ActivityForm
);

const mapStateToProps = state => ({
  fruits: state.fruits.data,
});

export default connect(
  mapStateToProps,
  { getFruits }
)(WrappedActivityForm);
