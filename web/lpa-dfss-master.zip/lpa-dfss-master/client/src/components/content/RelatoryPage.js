import React from 'react';

export default function RelatoryPage() {
  return (
    <div>
      <h1>RELATORIO</h1>
    </div>
  );
}
