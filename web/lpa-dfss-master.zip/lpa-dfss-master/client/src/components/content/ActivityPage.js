import React, { Component } from 'react';
import axios from 'axios';
import './ActivityPage.css';
import ActivityCard from './ActivityPage/ActivityCard';

const NUM_CAMARAS = 4;

class ActivityPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataLoaded: false,
      camaras: [],
    };

    this.fetchCamarasData = this.fetchCamarasData.bind(this);
    this.reloadActivityPage = this.reloadActivityPage.bind(this);
  }

  componentDidMount() {
    this.fetchCamarasData();
  }

  fetchCamarasData() {
    axios
      .get('/api/atividades/on')
      .then(res => {
        let aux = 0;

        for (let i = 1; i <= NUM_CAMARAS; i++) {
          if (res.data.length > aux && res.data[aux].camaras_id_camara === i) {
            const camaraObj = {
              id: i,
              status: 'ON',
              data: { ...res.data[aux] },
            };
            this.setState({ camaras: [...this.state.camaras, camaraObj] });

            aux += 1;
          } else {
            const camaraObj = { id: i, status: 'OFF', data: null };

            this.setState({ camaras: [...this.state.camaras, camaraObj] });
          }
        }
        this.setState({ dataLoaded: true });
      })
      .catch(err => console.log(err));
  }

  reloadActivityPage() {
    this.setState(
      {
        dataLoaded: false,
        camaras: [],
      },
      () => {
        this.fetchCamarasData();
      }
    );
  }

  render() {
    return (
      <>
        <h1 className="section-title">Cadastro atividades</h1>
        <div className="activity-cards-flex">
          {this.state.dataLoaded && (
            <>
              <ActivityCard
                id={this.state.camaras[0].id}
                status={this.state.camaras[0].status}
                data={this.state.camaras[0].data}
                reload={this.reloadActivityPage}
              />
              <ActivityCard
                id={this.state.camaras[1].id}
                status={this.state.camaras[1].status}
                data={this.state.camaras[1].data}
                reload={this.reloadActivityPage}
              />
              <ActivityCard
                id={this.state.camaras[2].id}
                status={this.state.camaras[2].status}
                data={this.state.camaras[2].data}
                reload={this.reloadActivityPage}
              />
              <ActivityCard
                id={this.state.camaras[3].id}
                status={this.state.camaras[3].status}
                data={this.state.camaras[3].data}
                reload={this.reloadActivityPage}
              />
            </>
          )}
        </div>
      </>
    );
  }
}

export default ActivityPage;
