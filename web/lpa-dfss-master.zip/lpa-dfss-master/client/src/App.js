import React, { useEffect } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Layout } from 'antd';
import store from './store';
import { loadUser } from './actions/auth';
import setAuthToken from './utils/setAuthToken';

import NavBar from './components/layout/NavBar';
import SideMenu from './components/layout/SideMenu';
import Routes from './components/routing/Routes';

import LoginPage from './components/auth/LoginPage';

import './App.css';

const { Content } = Layout;

if (localStorage.token) {
  setAuthToken(localStorage.token);
}

export default function App() {
  useEffect(() => {
    store.dispatch(loadUser());
  }, []);

  return (
    <Provider store={store}>
      <Router>
        <Layout>
          <SideMenu />
          <Layout>
            <NavBar />
            <Content style={{ margin: '24px 16px 0' }}>
              <div className="content-box">
                <Switch>
                  <Route exact path="/" component={LoginPage} />
                  <Route component={Routes} />
                </Switch>
              </div>
            </Content>
          </Layout>
        </Layout>
      </Router>
    </Provider>
  );
}
