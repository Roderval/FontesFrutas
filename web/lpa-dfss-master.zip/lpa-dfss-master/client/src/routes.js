import React from 'react';

function routes() {
  return <div />;
}

export default routes;
