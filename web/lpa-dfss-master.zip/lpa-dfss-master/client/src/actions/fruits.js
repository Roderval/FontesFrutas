import axios from 'axios';
import { GET_FRUITS } from './types';

export const getFruits = () => async dispatch => {
  try {
    const res = await axios.get('/api/frutas');

    dispatch({
      type: GET_FRUITS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};
