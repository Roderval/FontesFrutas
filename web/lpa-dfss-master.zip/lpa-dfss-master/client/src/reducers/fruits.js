import { GET_FRUITS } from '../actions/types';

const initialState = {
  data: [],
};

export default function(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case GET_FRUITS:
      return {
        ...state,
        data: payload,
      };
    default:
      return state;
  }
}
