const mysql = require("mysql");

module.exports = mysql.createPool({
  connectionLimit: 10,
  host: "191.52.60.25",
  user: "root",
  password: "raspberry",
  database: "bancomestrado"
});

/* module.exports = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "root",
  password: "master",
  database: "bancomestrado"
}); */
